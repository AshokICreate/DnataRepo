define (function (require) {
    var appDispatcher = require ("util/appDispatcher");
    var constants = require ("constants/homeConstants");
    var formActions = {
        getFormData: function (id) {
            appDispatcher.dispatch ({
                actionType: constants.Form_data,
                formId: id
            });
        }
    };
    return formActions;
});