define (function () {
    return {
        Navigation_PUSH: "navigation_push",
        Navigation_POP: "navigation_pop",
        Navigation_Clear: "navigation_clear",
        CHANGE_EVENT: 'navigation_change'
    };
});
