define (function () {
    return {
        Form_Data: "form_data"
    };
});