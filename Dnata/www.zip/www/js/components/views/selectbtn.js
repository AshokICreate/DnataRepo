define (function (require) {
    var selectbutton = React.createClass ({displayName: "selectbutton",
        render: function () {
            return (
                React.createElement("div", {className: "buttonContainer"}, 
                  React.createElement("div", {className: "buttonName", onClick: this.props.click}, getString(this.props.name))
                )
            );
        }
    });
    return selectbutton;
});
