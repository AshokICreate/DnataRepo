define (function (require) {
    var Dispatcher = require ('flux').Dispatcher;
    return new Dispatcher ();
});
