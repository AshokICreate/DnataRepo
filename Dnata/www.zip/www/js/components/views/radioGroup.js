define(function(require){

  var radioGroup = React.createClass({displayName: "radioGroup",

  propTypes: {
    name: React.PropTypes.string.isRequired,
    options:React.PropTypes.array.isRequired,
    onSave: React.PropTypes.func.isRequired
  },
  _handleChange: function(event) {
    this.props.onSave(this.props.id, event.target.value);
  },

  render:function(){
    var name = this.props.name;
    var array = this.props.options;
    var className = "radiogroup";
    var content = [];

    for (var i = 0; i < array.length; i++) {

        if(array[i] === this.props.value)
        {
          content.push(
              React.createElement("input", {key: i, className: className, name: "gender", type: "radio", onChange: this._handleChange, value: array[i], checked: true}, array[i])
          );
        }else {
          content.push(
              React.createElement("input", {key: i, className: className, name: "gender", type: "radio", onChange: this._handleChange, value: array[i]}, array[i])
          );
        }


      }
    return(
      React.createElement("div", {className: "inputBox"}, 
      React.createElement("div", {className: "label"}, getString(name)), 
      content
      )
      );
    }
  });
return radioGroup;
});
