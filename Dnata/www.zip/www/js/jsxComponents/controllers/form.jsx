define(function (require) {
  var actions = require ("actions/formActions");
  var Store = require ("stores/formStore");

  var form = React.createClass ({
      getInitialState: function () {
          return getState();
      },
      componentDidMount: function () {
          Store.addChangeListener (this._onChange);
      },
      componentWillUnmount: function () {
          Store.removeChangeListener (this._onChange);
      },
      render: function () {
          return (
              <div className="gclass">
              </div>
          );
      }
  });
  return form;

});
