define(function(require){

  var checkGroup = React.createClass({displayName: "checkGroup",

  propTypes: {
    name: React.PropTypes.string.isRequired,
    options:React.PropTypes.array.isRequired,
    onSave: React.PropTypes.func.isRequired
  },

  _handleChange: function(event) {
    this.props.onSave(this.props.id, event.target.value, event.target.checked);
  },

  getContents: function(){
    var array = this.props.options;
    var className = "radiogroup";
    var content = [];

    for (var i = 0; i < array.length; i++) {
        var check = this.props.value
        var flag = false;
        for(var j = 0; j< check.length; j++){
          if(array[i] === check[j]){
            flag = true;
            break;
          }
        }
        if(flag)
        {
            content.push(
                React.createElement("input", {key: i, className: className, name: "mobile", type: "checkbox", onChange: this._handleChange, value: array[i], checked: true}, array[i])
            );
          }
          else {
              content.push(
                  React.createElement("input", {key: i, className: className, name: "mobile", type: "checkbox", onChange: this._handleChange, value: array[i]}, array[i])
            );
        }
      }

      return content;
  },


  render:function(){
    var name = this.props.name;
    return(
      React.createElement("div", {className: "inputBox"}, 
      React.createElement("div", {className: "label"}, getString(name)), 
      this.getContents()
      )
      );
    }
  });
return checkGroup;
});
