define (function (require) {
  var appDispatcher = require ("util/appDispatcher");
  var EventEmitter = require ("event-emitter").EventEmitter;
  var assign = require ("object-assign");
  var constants = require ("constants/homeConstants");
  
  var homeMenuItems = ["MS_INC_ACTUAL_INJURY","MS_INC_POTENTIAL_INJ_FORM","feedback","observation","safety_contact","settings"];
  var injuryFormItems = ["PSD","FLY","WAB", "SBR","DGR","EQD","PRD", "PAE"];

  var getFormData = function(key)
  {

  }

  var store = assign ({}, EventEmitter.prototype, {

    getHomeMenuItems:function()
    {
      return homeMenuItems;
    },
    getInjuryFormItems:function()
    {
      return injuryFormItems;
    },
    emitChange: function() {
      this.emit(constants.CHANGE_DATA_EVENT);
    },
    addChangeListener: function(callback) {
      this.on(constants.CHANGE_DATA_EVENT, callback);
    },
    removeChangeListener: function(callback) {
      this.removeListener(constants.CHANGE_DATA_EVENT, callback);
    }

  });


  appDispatcher.register (function (action) {
    switch (action.actionType) {
      case constants.Form_Data:
      {
        getFormData(action.formId);
        store.emitChange();
        break;
      }
      default:
      {
        console.log ("No Registered action");
      }
    }
  });

  return store;

});
