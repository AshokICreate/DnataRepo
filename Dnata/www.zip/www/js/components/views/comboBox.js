define(function(require){

  var comboBox = React.createClass({displayName: "comboBox",

    // getInitialState: function() {
    //   var val = null;
    //   return { value: val};
    // },

   _handleChange: function(event) {
//    this.setState({value: event.target.value});
    this.props.onSave(this.props.id, event.target.value);
   },

    render: function(){
      var label = this.props.name;
    //  var value = this.state.value;
      var array=this.props.options;
      var className = "field";
      var content = [];
      for (var i = 0; i < array.length; i++) {
        var obj = array[i];
        content.push(
          React.createElement("option", {key: i, value: obj.value}, obj.name)
        );
      }
      return(
        React.createElement("div", {className: "inputBox"}, 
        React.createElement("div", {className: "label"}, getString(this.props.label)), 
        React.createElement("select", {onChange: this._handleChange}, 
        content
        )
        )
      );
    }
  });
  return comboBox;
});
