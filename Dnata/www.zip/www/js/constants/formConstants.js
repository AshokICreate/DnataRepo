define (function () {
    return {
        Form_Clear: "form_clear",
        Form_CreateText: "form_createtext",
        CHANGE_DATA_EVENT: 'form_data_change'
    };
});
